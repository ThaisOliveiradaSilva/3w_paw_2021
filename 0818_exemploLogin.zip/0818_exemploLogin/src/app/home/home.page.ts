import { Component } from '@angular/core';
import { Validators } from '@angular/forms';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage {
login = '';
senha = '';
mensagem = '';
  constructor() {}
  validar(): void{
    if(this.login === 'admin' && this.senha === '1234'){
      this.mensagem = 'Logado com sucesso!'
    }else{
      this.mensagem = 'Login ou Senha incorretos!'
    }
  }


}
